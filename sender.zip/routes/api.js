const express  = require('express')
const { send_tracker  } = require('../controller/apiController.js')

const router = express.Router()


router.post('/send/:link' , send_tracker)


module.exports = router;