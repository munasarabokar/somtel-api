const db = require('../database/data.js')
const sendAll = require('../models/send.js');
const confirmTransection = require('../models/confirm.js');

 const send_tracker = (req , res ) => {
    // massage body
    const massage_body = req.body.list;
    const sender = req.body.senderD
 const find_key = "SELECT * FROM user_login WHERE  deviceid = ? ";
 const value = [req.params.link];
 // db query 
 db.query(find_key , value , (err , find_keys ) => {
    const numbers = '';
    const check = '';
   if(err) res.json('false');
   if (find_keys.length > 0  ) { 
        // check if 
        if(find_keys[0].xaalada == 'active') {
          if (sender == '192') {
            const number  = massage_body.replace(/[^0-9\.]+/g, ",");
            var n_arr = []
            const words = number.split(",")
            words.forEach(counts)
            function counts(count) {
              n_arr.push({ count })
            }
            const check_massage = 'SELECT * FROM amounts WHERE amount = ?';
            db.query(check_massage , [n_arr[1].count]+' ' , (err , ress ) => {
                if(err) res.status(500).json(err);
                if (ress.length > 0) {
                    const amount = n_arr[1].count;
                    const numbers = n_arr[2].count.substring(1)
                    sendAll(numbers, find_keys[0].pin, find_keys[0].user_id ,amount).then(result => {
                        /* process */
                    res.json(result)
                    });
                     
                } else {
                    res.json('false')
                }
               
            })
          } else if (sender == 'Reseller') {
            const number  = massage_body.replace(/[^0-9\.]+/g, ",");
                var n_arr = []
                const words = number.split(",")
                words.forEach(counts)
                function counts(count) {
                n_arr.push({ count })
                }
                const balance = n_arr[4].count
                const numbers = n_arr[1].count
                confirmTransection(numbers, find_keys[0].user_id , balance).then(result => {
                    /* process */
                            res.json(result)
                    
                    })
                // res.json(n_arr)
          } else {
            res.json('false')
          }
        } else {
            res.json('banned');
        }
        
       
   } else {
       res.json("invalid");
   }
 });
  
}

module.exports = {
 send_tracker
}
